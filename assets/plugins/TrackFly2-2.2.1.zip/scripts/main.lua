-- TRACKFLY 2.2.1 : SKYLINE CIRCUIT
-- Requires the mouse-controls review host: mouse_yaw/mouse_pitch impulses plus TrackFly 2.2 host support.
-- Only Lua's math library exists in the sandbox: no string/table/tostring/ipairs, so text is formatted by hand.
--
-- Rendering notes (from the shell's shaders): gameplay meshes are drawn as  texture * tint * (0.3 + 0.7*diffuse)
-- with the light fixed toward (0.4, 0.8, 0.5), and the post pass blooms anything brighter than ~0.28.  So effect
-- meshes carry all-up normals (steady ~85% brightness whatever their yaw) and glow on their own.

local SFX = true  -- false = silent (no sample or engine sounds)

local sin, cos, sqrt, abs, min, max, floor, atan, asin, exp, pi =
  math.sin, math.cos, math.sqrt, math.abs, math.min, math.max, math.floor, math.atan, math.asin, math.exp, math.pi

local MODEL = asset_model("assets/craft.glb")
local T_HULL, T_FLAME = asset_texture("assets/hull.png"), asset_texture("assets/flame.png")
local T_CHECK, T_START, T_FINISH = asset_texture("assets/check.png"), asset_texture("assets/start.png"), asset_texture("assets/finish.png")

-- Total velocity includes forward, lateral and vertical motion; camera corrections have separate headroom.
local VM, VB, POSE_MAX = 300, 800, 900 -- cruise / boost / maximum camera speed (units/second)
local HR = 6                -- hoop radius (the start/finish hoop is 25% bigger)
local SC = 0.75             -- craft model scale
local CH = 1.05             -- camera height above the craft centre (chase distance is dynamic: 4.5 .. 6.6)
local PN = 28               -- ember pool size

local function cl(v, a, b) return v < a and a or (v > b and b or v) end
local function z2(n) return n < 10 and "0"..n or ""..n end
local function tf(ms)  -- integer milliseconds -> M:SS.CC
  if ms >= 600000 then return "9:59.99" end
  return (ms//60000)..":"..z2(ms//1000%60).."."..z2(ms//10%100)
end

-- ---------------------------------------------------------------- state
local ob, g, NG, ph, SIG = {}, {}, 0, 0, 0        -- scene handles, gates, gate count, phase (0 meshes,1 scan,2 build,3 ready)
local M, mk = {}, 0                               -- mesh handles, mesh build stage
local si, R0, LIM, bi, bj = 0, 0, 0, 1, 0         -- scan index, city radius, flight radius limit, leg sampler
local fl, kx, ky, kz, bk = false, 0, 0, 0, false  -- flying, inputs, boost held
local clickboost = false
local mouseyaw, mousepitch = 0, 0
local speedx, speedy, speedz, actualspeed = nil, 0, 0, 0
local function resetmotion()
  mouseyaw, mousepitch, speedx, actualspeed = 0, 0, nil, 0
end
local padinput = {}
local function resetpad()
  padinput = {lx=0, ly=0, rx=0, ry=0, lt=0, rt=0, a=0, rb=0, lb=0, x=0, y=0, up=0, down=0, left=0, right=0}
end
local function resetinput()
  kx, ky, kz, bk, clickboost = 0, 0, 0, false, false
  resetmotion()
  resetpad()
end
resetpad()
local vx, vy, vz, wr, roll, en, wasb = 0, 0, 0, 0, 0, 1, false  -- velocity, yaw rate, bank, boost energy
local cd = 4.5                                    -- chase distance (craft ahead of camera)
local pend, ppx, ppy, ppz = false, 0, 0, 0        -- last proposed camera position (to detect collisions)
local pcx, pcy, pcz, tp = nil, 0, 0, 0            -- previous craft centre and time (gate crossing)
local ccx, ccy, ccz = 0, 0, 0                     -- last craft centre (for sparks)
local nxt, run, t0, spl, lapn = 1, false, 0, {}, 0 -- next gate, lap running, lap start, splits, laps started
local best, bsp = {0, 0, 0, 0, 0}, {}             -- top-5 laps (ms), best-lap splits
local msg, mt, dl, dlt, ht, lastlap = "", 0, 0, 0, 0, 0
local craft, pad, pad2, bc, DL, DH = nil, nil, nil, nil, {}, {}
local PX, PY, PZ, PW = 0, 0, 0, 0                 -- parked craft position
local wq, wi, wt, tok, tg = {}, 1, 0, 3, 0        -- storage queue, sound tokens
local dm, dcol = {}, nil
local CY, AM, GR, OFF = {.25, .9, 1}, {1, .7, .1}, {.2, 1, .35}, {.04, .05, .07}
-- effects
local FO, FC, ST, P, RP = {}, {}, {}, {}, {}      -- flame outer/core, speed streaks, embers, hoop ripples
local BS, BF, STRIP = nil, nil, nil
local PYL, LMP = {}, {}                           -- start gate pylons and lamps
local pe, ea, ei, fb, rpi = 0, 0, 1, nil, 0       -- ember cursor/accumulator/engine, flame colour state, ripple cursor
local oc = {cy = 1, sy = 0, cp = 1, sp = 0, cr = 1, sr = 0}  -- trig cache for craft-local -> world offsets

local function o(h) ob[#ob+1] = h return h end
local function hide(h) scene_move(h, 0, -900, 0) end
local function snd(n, v)
  if SFX and tok >= 1 and tg <= 0 then tok = tok - 1 tg = .25 sound_sample("assets/"..n..".wav", v, false) end
end
local function sw(k, v) wq[#wq+1] = k wq[#wq+1] = floor(v) end

-- ---------------------------------------------------------------- procedural meshes (built one per frame at start-up)
local function pv(v, a, b, c, d, e, f, g, h)  -- append one vertex: position, normal, uv
  local n = #v
  v[n+1], v[n+2], v[n+3], v[n+4], v[n+5], v[n+6], v[n+7], v[n+8] = a, b, c, d, e, f, g, h
end
local function tri2(ix, a, b, c)  -- both windings, so effect meshes never depend on face culling
  local n = #ix
  ix[n+1], ix[n+2], ix[n+3], ix[n+4], ix[n+5], ix[n+6] = a, b, c, a, c, b
end

-- Hoop: unit ring in the XY plane (axis along Z), tube radius .075.  Normals lean toward +Y so the ring glows evenly.
local function mk_torus()
  local v, ix, N, T = {}, {}, 32, 10
  for i = 0, N do
    local a = i/N*2*pi
    local ca, sa = cos(a), sin(a)
    for j = 0, T do
      local b = j/T*2*pi
      local cb, sb = cos(b), sin(b)
      local r = 1 + .075*cb
      local nx, ny, nz = cb*ca*.45, cb*sa*.45 + .9, sb*.45
      local l = sqrt(nx*nx + ny*ny + nz*nz)
      pv(v, r*ca, r*sa, .075*sb, nx/l, ny/l, nz/l, i/N, j/T)
    end
  end
  for i = 0, N-1 do
    for j = 0, T-1 do
      local a = i*(T+1) + j + 1
      local b = a + T + 1
      local n = #ix
      ix[n+1], ix[n+2], ix[n+3], ix[n+4], ix[n+5], ix[n+6] = a, b, b+1, a, b+1, a+1
    end
  end
  return mesh_create(v, ix)
end

-- Exhaust plume: a teardrop along +Z (radius 1 at the nozzle, a point at z=1).  Texture v runs down its length.
local function mk_flame()
  local v, ix, N, K = {}, {}, 12, 8
  for k = 0, K do
    local t = k/K
    local r = (1 - t)^.75*(1 + .3*sin(pi*t))
    for i = 0, N do
      local a = i/N*2*pi
      pv(v, r*cos(a), r*sin(a), t, 0, 1, 0, i/N, t)
    end
  end
  for k = 0, K-1 do
    for i = 0, N-1 do
      local a = k*(N+1) + i + 1
      local b = a + N + 1
      tri2(ix, a, b+1, b)
      tri2(ix, a, a+1, b+1)
    end
  end
  return mesh_create(v, ix)
end

-- Ember / spark: a small low-poly ball.
local function mk_ember()
  local v, ix, N, K = {}, {}, 8, 5
  for k = 0, K do
    local ph_ = k/K*pi
    for i = 0, N do
      local a = i/N*2*pi
      pv(v, sin(ph_)*cos(a), cos(ph_), sin(ph_)*sin(a), 0, 1, 0, i/N, k/K)
    end
  end
  for k = 0, K-1 do
    for i = 0, N-1 do
      local a = k*(N+1) + i + 1
      local b = a + N + 1
      tri2(ix, a, b, b+1)
      tri2(ix, a, b+1, a+1)
    end
  end
  return mesh_create(v, ix)
end

-- Banner / ground line: a double-sided 1x1 quad in the XY plane; the back face is mirrored so text reads from both sides.
local function mk_banner()
  local v, ix = {}, {}
  pv(v, -.5,  .5,  .01, 0, 1, 0, 0, 0) pv(v, .5,  .5,  .01, 0, 1, 0, 1, 0)
  pv(v,  .5, -.5,  .01, 0, 1, 0, 1, 1) pv(v, -.5, -.5,  .01, 0, 1, 0, 0, 1)
  pv(v, -.5,  .5, -.01, 0, 1, 0, 1, 0) pv(v, .5,  .5, -.01, 0, 1, 0, 0, 0)
  pv(v,  .5, -.5, -.01, 0, 1, 0, 0, 1) pv(v, -.5, -.5, -.01, 0, 1, 0, 1, 1)
  ix = {1, 4, 3, 1, 3, 2,  5, 7, 8, 5, 6, 7}
  return mesh_create(v, ix)
end

local function mkstep()  -- one mesh per frame keeps every callback far below the 100k-instruction budget
  mk = mk + 1
  if mk == 1 then M.tor = mk_torus()
  elseif mk == 2 then M.fl = mk_flame()
  elseif mk == 3 then M.em = mk_ember()
  else M.ban = mk_banner() end
end

-- ---------------------------------------------------------------- 7-segment timer built from boxes
local SEG = {{0,.4,.34,.075}, {.2,.2,.075,.34}, {.2,-.2,.075,.34}, {0,-.4,.34,.075}, {-.2,-.2,.075,.34}, {-.2,.2,.075,.34}, {0,0,.34,.075}}
local CX, MASK = {-1.55, -.45, .15, 1.05, 1.65}, {63, 6, 91, 79, 102, 109, 125, 7, 127, 111}
local function dmake()
  for c = 1, 5 do
    DH[c] = {}
    for s = 1, 7 do
      local q = SEG[s]
      local h = o(scene_box(0, -900, 0, q[3], q[4], .03, OFF[1], OFF[2], OFF[3]))
      DH[c][s] = h
      DL[#DL+1] = {h, CX[c] + q[1], q[2], q[3], q[4]}
    end
  end
  for i = 1, 3 do  -- colon (two dots) and decimal point
    local h = o(scene_box(0, -900, 0, .09, .09, .03, OFF[1], OFF[2], OFF[3]))
    DH[5+i] = h
    DL[#DL+1] = {h, i == 3 and .62 or -1, i == 1 and .2 or (i == 2 and -.2 or -.4), .09, .09}
  end
end
local function dsize(k)  -- rescale display (HUD size vs parked size)
  for i = 1, #DL do local d = DL[i] scene_resize(d[1], d[4]*k, d[5]*k, .03*k) end
end
local function dplace(ox, oy, oz, Rx, Rz, Ux, Uy, Uz, k, rt, ry)
  for i = 1, #DL do
    local d = DL[i]
    local a, b = d[2]*k, d[3]*k
    scene_move(d[1], ox + Rx*a + Ux*b, oy + Uy*b, oz + Rz*a + Uz*b)
    scene_rotate(d[1], rt, ry, 0)
  end
end
local function dset(ms, col)  -- ms < 0 shows dashes
  local dg = {-1, -1, -1, -1, -1}
  if ms >= 0 then ms = min(ms, 599999) dg = {ms//60000, ms//10000%6, ms//1000%10, ms//100%10, ms//10%10} end
  for c = 1, 5 do
    local m = dg[c] < 0 and 64 or MASK[dg[c]+1]
    if m ~= dm[c] or col ~= dcol then
      dm[c] = m
      for s = 1, 7 do
        local k = m & (1 << (s-1)) ~= 0 and col or OFF
        scene_colour(DH[c][s], k[1], k[2], k[3])
      end
    end
  end
  if col ~= dcol then for i = 6, 8 do scene_colour(DH[i], col[1], col[2], col[3]) end dcol = col end
end

-- ---------------------------------------------------------------- scoreboard
local function ins(ms)
  local r = 6
  for i = 1, 5 do if best[i] == 0 or ms < best[i] then r = i break end end
  if r > 5 then return 0 end
  for i = 5, r+1, -1 do best[i] = best[i-1] sw("b"..i, best[i]) end
  best[r] = ms sw("b"..r, ms) sw("sg", SIG)
  return r
end
local function load()
  if storage_get("sg") == SIG then
    for i = 1, 5 do best[i] = floor(storage_get("b"..i) or 0) end
    for k = 2, NG do bsp[k] = floor(storage_get("s"..k) or 0) end
  else
    best, bsp = {0, 0, 0, 0, 0}, {}
  end
end
local function board(a, b)
  local s = ""
  for i = a, b do if best[i] > 0 then s = s..(s == "" and "" or " ").."#"..i.." "..tf(best[i]) end end
  return s
end

-- ---------------------------------------------------------------- effects
-- craft-local offset -> world offset, in the host's order: roll about Z, then pitch about X, then yaw about Y
local function setrot(pit, yaw, rl)
  oc.cy, oc.sy, oc.cp, oc.sp, oc.cr, oc.sr = cos(yaw), sin(yaw), cos(pit), sin(pit), cos(rl), sin(rl)
end
local function rotl(x, y, z)
  local x1, y1 = x*oc.cr - y*oc.sr, x*oc.sr + y*oc.cr
  local y2, z2 = y1*oc.cp - z*oc.sp, y1*oc.sp + z*oc.cp
  return x1*oc.cy + z2*oc.sy, y2, -x1*oc.sy + z2*oc.cy
end
local ENG = {{1.62, .03, 1.80, 1}, {-1.62, .03, 1.80, 1}, {.42, 0, 1.51, .6}, {-.42, 0, 1.51, .6}}  -- nozzle x,y,z (model units), size

local function ecol(k, f)  -- ember colour by life fraction: 1 exhaust (yellow > red > smoke), 2 spark, 3 boost (ice blue)
  if k == 3 then
    if f < .35 then return .7 + .3*f, .9, 1 end
    return max(.05, .7*(1 - f)), max(.08, .9*(1 - f)), max(.15, 1 - f*.8)
  elseif k == 2 then
    return 1, max(.15, 1 - f*1.1), max(0, .55 - f*1.2)
  end
  if f < .25 then return 1, .85 - f*1.4, .35 - f end
  if f < .6 then local u = (f - .25)/.35 return 1 - .5*u, .5 - .38*u, .1 - .06*u end
  local u = (f - .6)/.4
  return .5 - .32*u, .12 + .04*u, .04 + .1*u
end
local function emit(x, y, z, vx_, vy_, vz_, life, size, kind)
  pe = pe % PN + 1
  local q = P[pe]
  q.a, q.l, q.x, q.y, q.z, q.vx, q.vy, q.vz, q.s, q.k = 0, life, x, y, z, vx_, vy_, vz_, size, kind
end
local function particles(dt)
  for i = 1, PN do
    local q = P[i]
    if q.l > 0 then
      q.a = q.a + dt
      local f = q.a/q.l
      if f >= 1 then
        q.l = 0
        hide(q.h)
      else
        q.x, q.y, q.z = q.x + q.vx*dt, q.y + q.vy*dt, q.z + q.vz*dt
        if q.k == 2 then q.vy = q.vy - 9*dt end
        local s = q.s*(1 - f)^.7
        local r, gg, b = ecol(q.k, f)
        scene_move(q.h, q.x, q.y, q.z)
        scene_resize(q.h, s, s, s)
        scene_colour(q.h, r, gg, b)
      end
    end
  end
end
local function sparks(n)
  for _ = 1, n do
    emit(ccx, ccy, ccz, random_range(-6, 6), random_range(0, 6), random_range(-6, 6), random_range(.3, .6), random_range(.05, .09), 2)
  end
end

-- Two nested plumes per engine (outer tinted plume + white-hot core), flickering; blue-white under boost.
local function flames(cx, cy, cz, pit, yaw, rl, thr, bst, tn)
  setrot(pit, yaw, rl)
  if bst ~= fb then
    fb = bst
    for i = 1, 4 do
      if bst then scene_colour(FO[i], .35, .65, 1) scene_colour(FC[i], .85, .95, 1)
      else scene_colour(FO[i], 1, .5, .12) scene_colour(FC[i], 1, .92, .65) end
    end
  end
  local base = .22 + .5*max(0, thr) + (bst and .85 or 0)  -- metres; short, because the chase camera looks down the plume
  for i = 1, 4 do
    local e = ENG[i]
    local flick = 1 + .13*sin(tn*53 + i*1.7) + .08*sin(tn*91 + i*3.1)
    local L = base*e[4]*flick
    local r = (.1 + .012*sin(tn*67 + i))*e[4]*(bst and 1.2 or 1)
    local ox, oy, oz = rotl(e[1]*SC, e[2]*SC, (e[3] - .06)*SC)
    local x, y, z = cx + ox, cy + oy, cz + oz
    scene_move(FO[i], x, y, z) scene_resize(FO[i], r, r, L) scene_rotate(FO[i], pit, yaw, rl)
    scene_move(FC[i], x, y, z) scene_resize(FC[i], r*.5, r*.5, L*.6) scene_rotate(FC[i], pit, yaw, rl)
  end
end

-- Exhaust embers trail off the nacelles and cool from yellow to red to smoke (blue under boost).
local function embers(dt, cx, cy, cz, Fx, Fz, thr, bst)  -- (inherits ~75% of the craft's velocity, drifts back slowly)
  ea = ea + dt*(7 + 24*max(0, thr) + (bst and 20 or 0))
  local n = 0
  while ea >= 1 and n < 3 do
    ea, n, ei = ea - 1, n + 1, 3 - ei
    local e = ENG[ei]
    local ox, oy, oz = rotl(e[1]*SC, e[2]*SC, (e[3] + .15)*SC)
    emit(cx + ox + random_range(-.05, .05), cy + oy + random_range(-.05, .05), cz + oz + random_range(-.05, .05),
         vx*.75 - Fx*1.2 + random_range(-.4, .4), vy*.75 + random_range(-.2, .4), vz*.75 - Fz*1.2 + random_range(-.4, .4),
         random_range(.3, .5), random_range(.04, .08)*(bst and 1.3 or 1), bst and 3 or 1)
  end
end

local function ripple(p)  -- expanding ring where a hoop was passed
  rpi = rpi % 2 + 1
  local r = RP[rpi]
  r.t, r.g = 0, p
  scene_move(r.h, p.x, p.y, p.z)
  scene_rotate(r.h, p.pt, p.yw, 0)
end
local function ripples(dt)
  for i = 1, 2 do
    local r = RP[i]
    if r.t >= 0 then
      r.t = r.t + dt
      local f = r.t/.5
      if f >= 1 then
        r.t = -1
        hide(r.h)
      else
        local s = r.g.s*(1 + 1.4*f)
        scene_resize(r.h, s, s, s)
        scene_colour(r.h, 1, 1 - .35*f, 1 - .9*f)
      end
    end
  end
end

-- ---------------------------------------------------------------- course
local function paint()  -- hoop colours, beacon position and which banner is up
  for i = 1, NG do
    local p = g[i]
    local r, gg, b
    if i == nxt then r, gg, b = 1, .82, .1
    elseif i == nxt % NG + 1 then r, gg, b = .15, .85, 1
    elseif p.d then r, gg, b = .1, .55, .25
    elseif i == 1 then r, gg, b = .9, .9, .95
    else r, gg, b = .15, .3, .6 end
    scene_colour(p.h, r, gg, b)
  end
  local p, s = g[nxt], g[1]
  scene_move(bc, p.x, p.y + (nxt == 1 and p.s + 11 or HR) + 48, p.z)  -- on the start gate the beam clears the banner
  if run then scene_move(BF, s.bx, s.by, s.bz) hide(BS) else scene_move(BS, s.bx, s.by, s.bz) hide(BF) end
end

local function scan()  -- city radar: 12 spokes x 14 rings of obstacle clearance, a few dozen queries per frame
  local n = 0
  while si < 168 and n < 44 do
    local a, r = (si % 12)*pi/6, 56 + 60*(si//12)
    if r > R0 and world_track_clearance(r*cos(a), r*sin(a), 36) > 0 then R0 = r end
    si, n = si + 1, n + 1
  end
  return si >= 168
end

local function plan(x, z)  -- lay out the loop around the hub, radius wobbling between ~.3R and ~.75R
  local R = max(110, R0 + 10)
  NG = cl(floor(R/26), 8, 14)
  SIG = NG*1000 + floor(R/25)
  LIM = max(R0 + 50, sqrt(x*x + z*z) + 30)
  for i = 1, NG do
    local a = -pi/2 + (i-1)*2*pi/NG
    local rd = max(60, R*(.52 + .16*sin(2*a + .8) + .07*sin(3*a + 2.1)))
    g[i] = {x = rd*cos(a), z = rd*sin(a), c = 0, m = 0}
  end
  for i = 1, NG do  -- one obstacle probe roughly every 32 m along each leg
    local p, q = g[i], g[i % NG + 1]
    p.n = cl(floor(sqrt((p.x-q.x)^2 + (p.z-q.z)^2)/32) + 1, 2, 10)
  end
end

local function sample()  -- obstacle height at each hoop and along each leg, a few dozen queries per frame
  local n = 0
  while bi <= NG and n < 40 do
    local p, q = g[bi], g[bi % NG + 1]
    if bj == 0 then p.c = world_track_clearance(p.x, p.z, 16)
    else
      local u = bj/(p.n + 1)
      p.m = max(p.m, world_track_clearance(p.x + (q.x-p.x)*u, p.z + (q.z-p.z)*u, 18))
    end
    n, bj = n + 1, bj + 1
    if bj > p.n then bj, bi = 0, bi + 1 end
  end
  return bi > NG
end

local function build()
  for i = 1, NG do  -- fly 12-22 m over whatever is tallest nearby
    local p, pr = g[i], g[(i-2) % NG + 1]
    p.y = min(420, max(p.c, p.m, pr.m) + 12 + 10*(.5 + .5*sin(1.9*i + .5)))
  end
  for _ = 1, 3 do  -- limit climb/dive between hoops (only ever raises, so clearance is kept)
    for i = 1, NG do
      local p, q = g[i], g[i % NG + 1]
      local d = .4*sqrt((p.x-q.x)^2 + (p.z-q.z)^2)
      if q.y < p.y - d then q.y = p.y - d elseif p.y < q.y - d then p.y = q.y - d end
    end
  end
  for i = 1, NG do
    local p, q, pr = g[i], g[i % NG + 1], g[(i-2) % NG + 1]
    local dx, dz = q.x - pr.x, q.z - pr.z
    p.yw = atan(-dx, -dz)
    p.pt = cl(atan(q.y - pr.y, sqrt(dx*dx + dz*dz)), -.45, .45)
    local c = cos(p.pt)
    p.nx, p.ny, p.nz = -sin(p.yw)*c, sin(p.pt), -cos(p.yw)*c
    p.s = i == 1 and HR*1.25 or HR
    p.h = o(scene_mesh(M.tor, i == 1 and T_CHECK or 0, p.x, p.y, p.z, p.s, p.s, p.s, .15, .3, .6))
    scene_rotate(p.h, p.pt, p.yw, 0)
  end

  -- start / finish structure: chequered hoop, two light pylons from the roof up, a banner above, a chequered line below
  local s = g[1]
  local rx, rz = cos(s.yw), -sin(s.yw)
  local ux, uy, uz = sin(s.yw)*sin(s.pt), cos(s.pt), cos(s.yw)*sin(s.pt)
  local lift = s.s + 5.6
  s.bx, s.by, s.bz = s.x + ux*lift, s.y + uy*lift, s.z + uz*lift
  BS = o(scene_mesh(M.ban, T_START, 0, -900, 0, 20, 5, 1, 1, 1, 1))
  BF = o(scene_mesh(M.ban, T_FINISH, 0, -900, 0, 20, 5, 1, 1, 1, 1))
  scene_rotate(BS, s.pt, s.yw, 0)
  scene_rotate(BF, s.pt, s.yw, 0)
  for k = 1, 2 do
    local side = k == 1 and -1 or 1
    local px, pz = s.x + rx*(s.s + 3.6)*side, s.z + rz*(s.s + 3.6)*side
    local fy = world_floor(px, s.y, pz, .5, 0)
    local top = s.y + s.s + 11
    local hgt = max(6, top - fy)
    PYL[k] = o(scene_box(px, fy + hgt/2, pz, 1, hgt, 1, .88, .9, 1))
    LMP[k] = o(scene_box(px, top + .4, pz, 1.8, .8, 1.8, 1, .2, .8))
  end
  local gy = world_floor(s.x, s.y, s.z, 1, 0)
  STRIP = o(scene_mesh(M.ban, T_CHECK, s.x, gy + .09, s.z, 20, 5, 1, 1, 1, 1))
  scene_rotate(STRIP, -pi/2, s.yw, 0)
  bc = o(scene_box(0, -900, 0, .5, 90, .5, 1, .85, .2))

  pad = o(scene_mesh(M.tor, 0, 0, -900, 0, 1.7, 1.7, 1.7, 1, .85, .15))   -- launch pad: two flat rings
  pad2 = o(scene_mesh(M.tor, 0, 0, -900, 0, 1, 1, 1, .25, .9, 1))
  scene_rotate(pad, pi/2, 0, 0)
  scene_rotate(pad2, pi/2, 0, 0)
  craft = o(scene_model(MODEL, T_HULL, 0, -900, 0, SC, SC, SC, 1, 1, 1))
  for i = 1, 4 do
    FO[i] = o(scene_mesh(M.fl, T_FLAME, 0, -900, 0, .1, .1, .5, 1, .5, .12))
    FC[i] = o(scene_mesh(M.fl, T_FLAME, 0, -900, 0, .05, .05, .3, 1, .92, .65))
  end
  fb = nil
  for i = 1, PN do P[i] = {h = o(scene_mesh(M.em, 0, 0, -900, 0, .1, .1, .1, 1, .6, .15)), l = 0, a = 0, x = 0, y = 0, z = 0, vx = 0, vy = 0, vz = 0, s = 0, k = 1} end
  for i = 1, 2 do RP[i] = {h = o(scene_mesh(M.tor, 0, 0, -900, 0, HR, HR, HR, 1, 1, 1)), t = -1} end
  for i = 1, 12 do ST[i] = {o(scene_box(0, -900, 0, .05, .05, .3, .75, .9, 1)), 0, -900, 0} end
  dmake()
  paint()
end

-- ---------------------------------------------------------------- parked state (on the pad, scoreboard totem)
local function park()
  local x, y, z, dx, dy, dz = view_pose()
  if not x then return end
  local f = world_floor(x, y, z, .8, 1.7)
  local yw = atan(-dx, -dz)
  local sy, cy = sin(yw), cos(yw)
  PX, PY, PZ, PW = x - sy*4.5, f + .95, z - cy*4.5, yw
  scene_move(pad, x, f + .09, z)
  scene_move(pad2, x, f + .1, z)
  control_offer(x, f + 1.7, z)
  for i = 1, 12 do hide(ST[i][1]) end
  paint()
  dsize(.6)
  dset(best[1] > 0 and best[1] or -1, AM)
  dplace(PX, PY + 2.9, PZ, cy, -sy, 0, 1, 0, .6, 0, yw)
  fb = nil
end

local function clear()
  resetinput()
  vx, vy, vz, wr, roll, pend, wasb = 0, 0, 0, 0, 0, false, false
  if SFX then sound_engine(false, 0, false) end
  control_offer(nil)
  for i = 1, #ob do scene_remove(ob[i]) end
  ob, g, DL, DH, dm, dcol, FO, FC, ST, P, RP, PYL, LMP = {}, {}, {}, {}, {}, nil, {}, {}, {}, {}, {}, {}, {}
  ph, fl, pcx, NG, bi, bj, fb = 0, false, nil, 0, 1, 0, nil
  hud_set("")
end

-- ---------------------------------------------------------------- racing
local function finish(ms)
  local r = ins(ms)
  local nb = r == 1
  if nb then
    for k = 2, NG do bsp[k] = spl[k] or 0 sw("s"..k, bsp[k]) end
  end
  local d = ms - best[1]
  msg = "LAP "..tf(ms)..(nb and " NEW BEST!" or (r > 0 and " RANK "..r or " +"..(d//1000).."."..z2(d//10%100)))
  mt, lastlap = 6, ms
  snd(nb and "best" or "lap", .9)
end

local function passed(tc)
  local k = nxt
  g[k].d = true
  ripple(g[k])
  if k == 1 then
    if run then finish(floor((tc - t0)*1000)) end
    run, t0, spl, lapn = true, tc, {}, lapn + 1
    for i = 2, NG do g[i].d = false end
    if mt <= 0 then msg, mt = "GO! LAP "..lapn, 1.5 end
    snd("go", .8)
  else
    local s = floor((tc - t0)*1000)
    spl[k] = s
    local b = bsp[k]
    if b and b > 0 then dl = s - b dlt = 2.5 end
    snd("gate", .7)
  end
  nxt = k % NG + 1
  paint()
end

local function gates(cx, cy, cz, tn)
  if pcx then
    local last = -1
    for _ = 1, NG do
      local p = g[nxt]
      local s0 = (pcx-p.x)*p.nx + (pcy-p.y)*p.ny + (pcz-p.z)*p.nz
      local s1 = (cx-p.x)*p.nx + (cy-p.y)*p.ny + (cz-p.z)*p.nz
      if s0 >= 0 or s1 < 0 then break end
      local f = s0/(s0 - s1)
      local qx, qy, qz = pcx + (cx-pcx)*f - p.x, pcy + (cy-pcy)*f - p.y, pcz + (cz-pcz)*f - p.z
      if f <= last or qx*qx + qy*qy + qz*qz >= (p.s*.92)^2 then break end
      last = f
      passed(tp + (tn-tp)*f)
    end
  end
  pcx, pcy, pcz, tp = cx, cy, cz, tn
end

-- ---------------------------------------------------------------- flight
local function hit(vn)  -- only real impacts cost speed; scraping along a wall lets you slide up/along it
  if vn > 3 then
    vx, vy, vz = vx*.85, vy*.85, vz*.85
    snd("crash", min(1, vn/14))
    sparks(8)
  end
end

local function limit(x, z, nx, nz)  -- keep inside the radius limit, sliding along it (also tolerates starting outside)
  local cur, pr = sqrt(x*x + z*z), sqrt(nx*nx + nz*nz)
  if pr > LIM then
    local ux, uz = nx/pr, nz/pr
    local vr = vx*ux + vz*uz
    if vr > 0 then vx, vz = vx - vr*ux, vz - vr*uz end  -- drop the outward speed so the speedo reads true
    if cur > LIM + .001 then
      if pr > cur then return x, z end
    else
      local e = max(LIM, cur)
      return nx*e/pr, nz*e/pr
    end
  end
  return nx, nz
end

local function arrow(a)  -- bearing arrow, 3 chars (a > 0: target to the left)
  return a > 1.2 and "<<<" or (a > .45 and "<< " or (a > .12 and "<  " or (a > -.12 and "[^]" or (a > -.45 and "  >" or (a > -1.2 and " >>" or ">>>")))))
end
local function dist(tx, tz, dy)
  return floor(min(999, sqrt(tx*tx + tz*tz)))..'M'..(dy > 8 and "+" or (dy < -8 and "-" or ""))
end

local function fly(dt, x, y, z, dx, dy, dz, tn, elapsed)
  -- Measure the host-accepted camera movement, including collision stops and slow frames.
  actualspeed = speedx and sqrt((x-speedx)^2 + (y-speedy)^2 + (z-speedz)^2)/elapsed or 0
  speedx, speedy, speedz = x, y, z
  local yaw, pit = atan(-dx, -dz), asin(cl(dy, -1, 1))
  local oldcd = cd
  local cp0, sp0 = cos(pit), sin(pit)
  local ax, ay, az = x - sin(yaw)*(cp0*oldcd + sp0*CH),
                     y + sp0*oldcd - cp0*CH, z - cos(yaw)*(cp0*oldcd + sp0*CH)
  if pend then  -- the host moved us less than proposed: we hit something. Cancel the speed into it, with a little bounce.
    local ex, ey, ez = ppx - x, ppy - y, ppz - z
    local el = sqrt(ex*ex + ey*ey + ez*ez)
    if el > .03 then
      ex, ey, ez = ex/el, ey/el, ez/el
      local vn = vx*ex + vy*ey + vz*ez
      if vn > 0 then vx, vy, vz = vx - 1.25*vn*ex, vy - 1.25*vn*ey, vz - 1.25*vn*ez hit(vn) end
    end
  end
  local thr = cl(ky + padinput.ly + padinput.rt - padinput.lt, -1, 1)
  local brake = padinput.lb > 0
  local bst = (bk or clickboost or padinput.a > 0 or padinput.rb > 0) and en > .03 and thr >= 0 and not brake
  if brake then thr = 0 end
  if bst then thr = 1 if not wasb then snd("boost", .6) end end
  wasb = bst
  en = bst and max(0, en - .27*dt) or min(1, en + .14*dt)
  local top = bst and VB or VM
  local sv = sqrt(vx*vx + vz*vz)
  wr = wr + (-cl(kx + padinput.lx, -1, 1)*(2.4 - .9*min(1, sv/VB)) - wr)*min(1, 6*dt)
  -- Host impulses are already sensitivity/invert-Y adjusted radians, not held axes.
  yaw = yaw + cl(wr*dt - mouseyaw, -3.8*dt, 3.8*dt)
  pit = cl(pit + cl(padinput.ry*1.4*dt - mousepitch, -3.8*dt, 3.8*dt), -1.1, 1.1)
  mouseyaw, mousepitch = 0, 0
  local fx, fz, rx, rz = -sin(yaw), -cos(yaw), cos(yaw), -sin(yaw)
  local vf, vl = vx*fx + vz*fz, vx*rx + vz*rz
  local target = thr*(thr >= 0 and top or VM*.35)
  local response = brake and 12 or (thr > 0 and (bst and 2.4 or 1.8) or (thr < 0 and 4 or 2.6))
  local grip = brake and 12 or 4
  vf = vf + (target*cos(pit) - vf)*(1 - exp(-response*dt))
  local lateral = cl(padinput.rx + padinput.right - padinput.left, -1, 1)*VM*.35
  vl = vl + ((brake and 0 or lateral) - vl)*(1 - exp(-grip*dt))
  vx, vz = fx*vf + rx*vl, fz*vf + rz*vl
  local lf = cl(kz + padinput.y - padinput.x + padinput.up - padinput.down, -1, 1)
  local vertical = target*sin(pit) + lf*VM*.35
  vy = vy + ((brake and 0 or vertical) - vy)*(1 - exp(-(brake and 12 or 4)*dt))
  local s3 = sqrt(vx*vx + vy*vy + vz*vz)
  if s3 > VB then local k = VB/s3 vx, vy, vz, s3 = vx*k, vy*k, vz*k, VB end
  roll = roll + (cl(.34*wr - .015*vl, -.75, .75) - roll)*min(1, 6*dt)
  cd = cd + (4.5 + 1.5*s3/VB + (bst and .6 or 0) - cd)*min(1, 2.5*dt)  -- the camera drops back as you speed up
  local nx, ny, nz = x + vx*dt, y + vy*dt, z + vz*dt
  if ny < 2 or ny > 440 then ny = cl(ny, 2, 440) vy = 0 end
  nx, nz = limit(x, z, nx, nz)
  -- craft body sits ahead of and below the camera; collide the body (not only the camera) with the city
  local cp, sp, cy_, sy_ = cos(pit), sin(pit), cos(yaw), sin(yaw)
  local Fx, Fy, Fz, Ux, Uy, Uz = -sy_*cp, sp, -cy_*cp, sy_*sp, cp, cy_*sp
  local cx, cy, cz = nx + Fx*cd - Ux*CH, ny + Fy*cd - Uy*CH, nz + Fz*cd - Uz*CH
  -- Sweep the body too: endpoint-only resolution tunnels through narrow buildings at 800 u/s.
  -- At most 48 queries (plus view/context) leaves room under the host's 64-query callback limit.
  local travel = sqrt((cx-ax)^2 + (cy-ay)^2 + (cz-az)^2)
  local steps = min(48, max(1, math.ceil(travel/1.25)))
  for i = 1, steps do
    local f = i/steps
    local sx, sy, sz = ax + (cx-ax)*f, ay + (cy-ay)*f, az + (cz-az)*f
    local qx, qy, qz = world_resolve(sx, sy, sz, 1.5, .4)
    local ex, ey, ez = qx - sx, qy - sy, qz - sz
    local el = sqrt(ex*ex + ey*ey + ez*ez)
    if el > .02 then
      ccx, ccy, ccz = qx, qy, qz
      nx, ny, nz = qx - Fx*cd + Ux*CH, qy - Fy*cd + Uy*CH, qz - Fz*cd + Uz*CH
      ex, ey, ez = ex/el, ey/el, ez/el
      local vn = vx*ex + vy*ey + vz*ez
      if vn < 0 then vx, vy, vz = vx - 1.1*vn*ex, vy - 1.1*vn*ey, vz - 1.1*vn*ez hit(-vn) end
      ny = cl(ny, 2, 440)
      nx, nz = limit(x, z, nx, nz)
      break
    end
  end
  local sx, sy, sz = nx - x, ny - y, nz - z
  local sl, cap = sqrt(sx*sx + sy*sy + sz*sz), POSE_MAX*dt
  if sl > cap then local k = cap/sl nx, ny, nz = x + sx*k, y + sy*k, z + sz*k end
  cx, cy, cz = nx + Fx*cd - Ux*CH, ny + Fy*cd - Uy*CH, nz + Fz*cd - Uz*CH
  ccx, ccy, ccz = cx, cy, cz
  control_pose(nx, ny, nz, yaw, pit)
  pend, ppx, ppy, ppz = true, nx, ny, nz

  -- visuals
  scene_move(craft, cx, cy, cz)
  scene_rotate(craft, pit, yaw, roll)
  flames(cx, cy, cz, pit, yaw, roll, thr, bst, tn)
  embers(dt, cx, cy, cz, Fx, Fz, thr, bst)
  local L = cl((s3 - 3)*.05, .03, 5)
  for i = 1, 12 do
    local s = ST[i]
    local fwd = (s[2]-nx)*Fx + (s[3]-ny)*Fy + (s[4]-nz)*Fz
    if fwd < -4 or fwd > 55 then
      local d, a, b = random_range(14, 52), random_range(-13, 13), random_range(-7, 7)
      s[2], s[3], s[4] = nx + Fx*d + cy_*a + Ux*b, ny + Fy*d + Uy*b, nz + Fz*d - sy_*a + Uz*b
    end
    scene_move(s[1], s[2], s[3], s[4])
    scene_resize(s[1], .05, .05, L)
    scene_rotate(s[1], pit, yaw, 0)
  end
  dplace(nx + Fx*3.1 + Ux*1.05, ny + Fy*3.1 + Uy*1.05, nz + Fz*3.1 + Uz*1.05, cy_, -sy_, Ux, Uy, Uz, .32, pit, yaw)
  if SFX then sound_engine(true, min(110, s3*3.3), bst) end

  gates(cx, cy, cz, tn)
  local p = g[nxt]
  if mt > 3.5 then dset(lastlap, GR) elseif run then dset(floor((tn - t0)*1000), CY) else dset(-1, CY) end
  -- guidance: bearing to the next hoop
  ht = ht + elapsed
  if ht >= .26 then
    ht = 0
    local tx, tz = p.x - cx, p.z - cz
    local a = (atan(-tx, -tz) - yaw + pi) % (2*pi) - pi
    local ar, d = arrow(a), dist(tx, tz, p.y - cy)
    local s
    if mt > 0 then
      s = lastlap > 0 and ("LAP "..tf(lastlap)..(lastlap == best[1] and " BEST" or "")) or ("GO LAP "..lapn)
    elseif run then
      s = nxt.."/"..NG.." "..tf(floor((tn - t0)*1000)).." "..ar.." "..d
    else s = "START "..ar.." "..d.." B"..floor(en*9.99) end
    hud_set(floor(actualspeed).."u/s "..s)
  end
end

-- parked: craft hovers on the pad, idling; HUD pages through the board, controls and the way to the start gate
local function idle(dt, x, z, dx, dz, tn)
  local by = PY + .12*sin(tn*2)
  scene_move(craft, PX, by, PZ)
  scene_rotate(craft, 0, PW, 0)
  flames(PX, by, PZ, 0, PW, 0, 0, false, tn)
  embers(dt, PX, by, PZ, -sin(PW), -cos(PW), 0, false)
  ht = ht + dt
  if ht >= .3 then
    ht = 0
    local pg = floor(tn/2.4) % 11
    local s = pg == 0 and board(1, 3) or (pg == 1 and board(4, 5) or "")
    if pg == 3 then
      local s1 = g[1]
      s = "START "..arrow((atan(-(s1.x - x), -(s1.z - z)) - atan(-dx, -dz) + pi) % (2*pi) - pi).." "..dist(s1.x - x, s1.z - z, s1.y - PY)
    elseif s == "" then
      if pg == 2 then s = "MOUSE STEER W/S THRUST/REV"
      elseif pg == 4 then s = "SPACE/CTRL UP/DN SHIFT BOOST"
      elseif pg == 5 then s = "XBOX START FLY/EXIT B/BACK EXIT"
      elseif pg == 6 then s = "LS YAW/THRUST  RS STRAFE/PITCH"
      elseif pg == 7 then s = "RT THRUST LT BRAKE/REV LB STOP"
      elseif pg == 8 then s = "Y/X OR DPAD UP/DN ALTITUDE"
      elseif pg == 9 then s = "A/RB BOOST  DPAD LEFT/RT STRAFE"
      else s = "G FLY/EXIT ESC EXIT CLICK BOOST" end
    end
    hud_set(s)
  end
end

-- gentle pulses on the targets and the start structure
local function pulses(tn)
  local k = .75 + .25*sin(tn*8)
  if run or nxt ~= 1 then
    scene_colour(g[nxt].h, 1, .75 + .15*sin(tn*8), .1)
    scene_colour(bc, 1, .85, .2)
  else  -- waiting for the start: gold chequered hoop, magenta beam
    scene_colour(g[1].h, 1, .75 + .15*sin(tn*8), .1)
    scene_colour(bc, 1, .2 + .2*sin(tn*5), .85)
  end
  for i = 1, 2 do scene_colour(LMP[i], 1, .15 + .2*k, .8) end
  scene_colour(pad, 1, .7 + .2*sin(tn*3), .1)
  scene_colour(pad2, .25, .75 + .2*sin(tn*3 + 2), 1)
end

return {
  on_start = function()
    hud_set("TRACKFLY: LOADING")
  end,
  on_input = function(k, v)
    if k == "move_x" then kx = v
    elseif k == "move_y" then ky = v
    elseif k == "move_z" then kz = v
    elseif k == "boost" then bk = v == 1
    elseif k == "click" then clickboost = v == 1
    elseif k == "mouse_yaw" then
      if fl then mouseyaw = cl(mouseyaw + v, -1, 1) end
    elseif k == "mouse_pitch" then
      if fl then mousepitch = cl(mousepitch + v, -1, 1) end
    elseif k == "gamepad_left_x" then padinput.lx = v
    elseif k == "gamepad_left_y" then padinput.ly = v
    elseif k == "gamepad_right_x" then padinput.rx = v
    elseif k == "gamepad_right_y" then padinput.ry = v
    elseif k == "left_trigger" then padinput.lt = v
    elseif k == "right_trigger" then padinput.rt = v
    elseif k == "button_a" then padinput.a = v
    elseif k == "button_x" then padinput.x = v
    elseif k == "button_y" then padinput.y = v
    elseif k == "dpad_up" then padinput.up = v
    elseif k == "dpad_down" then padinput.down = v
    elseif k == "dpad_left" then padinput.left = v
    elseif k == "dpad_right" then padinput.right = v
    elseif k == "pad_lb" then padinput.lb = v
    elseif k == "pad_rb" then padinput.rb = v
    elseif k == "pad_connected" and v == 0 then resetpad()
    elseif k == "control" then
      if v == 1 and ph == 3 then
        resetmotion()
        fl, vx, vy, vz, wr, roll, en, pend, pcx, run, nxt, mt, dlt, cd, wasb = true, 0, 0, 0, 0, 0, 1, false, nil, false, 1, 0, 0, 4.5, false
        for i = 1, NG do g[i].d = false end
        paint()
        dsize(.32)
        hud_set("0u/s START")
      else
        resetinput()
        fl, vx, vy, vz, pend, pcx, wasb = false, 0, 0, 0, false, nil, false
        if SFX then sound_engine(false, 0, false) end
        if ph == 3 and world_available() then park() end
      end
    end
  end,
  on_tick = function(dt)
    if not world_available() then
      if ph > 0 then clear() end
      hud_set("TRACKFLY: ENTER CITY")
      return
    end
    local x, y, z, dx, dy, dz = view_pose()
    if not x then resetmotion() return end
    local tn = time_now()
    tok, tg, mt, dlt = min(3, tok + dt*2.5), tg - dt, mt - dt, dlt - dt
    wt = wt - dt
    if wt <= 0 and wi < #wq then  -- one storage write per .3 s keeps us inside the host's rate limit
      storage_set(wq[wi], wq[wi+1])
      wi = wi + 2
      wt = .3
      if wi >= #wq then wq, wi = {}, 1 end
    end
    if ph == 0 then
      if mk < 4 then mkstep() hud_set("TRACKFLY: LOADING") return end
      ph, si, R0 = 1, 0, 0
    end
    if ph == 1 then
      hud_set("TRACKFLY: SURVEYING CITY")
      if scan() then ph = 2 end
      return
    end
    if ph == 2 then
      if NG == 0 then plan(x, z) end
      if sample() then
        build()
        load()
        ph = 3
        park()
      end
      return
    end
    particles(dt)
    ripples(dt)
    pulses(tn)
    if not fl or dt <= 0 then
      resetmotion()
      idle(dt, x, z, dx, dz, tn)
      return
    end
    fly(min(dt, .066), x, y, z, dx, dy, dz, tn, dt)
  end,
  on_stop = function()
    for _ = 1, 4 do
      if wi < #wq then storage_set(wq[wi], wq[wi+1]) wi = wi + 2 end
    end
    clear()
  end
}
